gsap.registerPlugin(ScrollTrigger)

document.addEventListener('DOMContentLoaded', () => {
	// === Smooth scroll (Lenis) ===
	const lenis = new Lenis({
		duration: 1.2,
		easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
		smoothWheel: true,
	})


	lenis.on('scroll', ScrollTrigger.update)

	gsap.ticker.add(time => {
		lenis.raf(time * 1000)
	})


	gsap.ticker.lagSmoothing(0)

	// === Footer reveal effect ===
	const footerContainer = document.querySelector('.footer-container')
	const canvasContainer = document.getElementById('footer-canvas')
	if (canvasContainer) {
		canvasContainer.style.display = 'none'
	}

	ScrollTrigger.create({
		trigger: 'footer',
		start: 'top bottom',
		end: 'bottom bottom',
		scrub: true,
		onUpdate: self => {
			const progress = self.progress
			gsap.set(footerContainer, {
				y: `${-35 * (1 - progress)}%`,
			})
		},
	})
})
